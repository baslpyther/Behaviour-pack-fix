import {
    world,
    system,
    Player,
    Entity
} from '@minecraft/server';








let vecUp = {x:0, y:1, z:0};
function vectorAdd(vec1, vec2) {
    let vecFinal = {x:vec1.x+vec2.x, y:vec1.y+vec2.y, z:vec1.z+vec2.z};
    return vecFinal;
};

function vectorMultiply(vec, value) {
    let multiply = {x:vec.x*value, y:vec.y*value, z:vec.z*value}
    return multiply;
};

const stop = (runId) => typeof runId == 'number' ? system.clearRun(runId): undefined
const testClickInterval = (data, seconds = 1) => {
    const millisec = 1e3 * (seconds <= 0 ? 1: seconds);
    const run = data.dateStamp;
    return !((data.dateStamp = Date.now()) - (run ?? 0) > millisec);
};

function limitAngle(value, max) {
    return Math.max(
        -max,
        Math.min(
            value + (360 * ((value > 180) ? -1: (value < -180) ? 1: 0)),
            max
        )
    )
};

//Special thanks to PavelDobCZ23#5726 for the offset functions!↓
function parseVector(carets, vector) {
    const coord = {
        x: 0,
        y: 0,
        z: 0
    };
    for (const axis in carets) {
        const number = carets[axis];
        let useVector;
        switch (axis) {
            case 'x':
                useVector = setVectorLength({
                    x: vector.z, y: 0, z: -vector.x
                }, number);
                break;
            case 'y':
                const total = Math.sqrt(vector.x**2+vector.z**2);
                useVector = setVectorLength({
                    x: (vector.x/total)*-vector.y, y: total, z: (vector.z/total)*-vector.y
                }, number);
                break;
            case 'z':
                useVector = setVectorLength(vector, number);
                break;
        }
        coord.x += useVector.x;
        coord.y += useVector.y;
        coord.z += useVector.z;
    }
    return coord;
}

function setVectorLength(vector, length) {
    const vectorLength = getVectorLength(vector);
    const ratio = length / vectorLength;
    vector.x *= ratio;
    vector.y *= ratio;
    vector.z *= ratio;
    return vector;
}

function getVectorLength(vector) {
    return Math.sqrt(vector.x * vector.x + vector.y * vector.y + vector.z * vector.z);
}

const commonLevels = [0.0, 0.0, 0.0, 0.0, 0, 0];
const commonShoot = [1, 1, [0, 0, 0], [0, 0, 0]];


world.afterEvents.entityHitEntity.subscribe(hit => {
    let player = hit.damagingEntity;
    const ridingOnEntity = player.getComponent("riding")?.entityRidingOn;
    let variant = ridingOnEntity?.getComponent("mark_variant").value;
    if (player instanceof Player && ridingOnEntity?.typeId.startsWith('sw') && variant != 1) {
        planeFly(ridingOnEntity);
    }
});

let speedBefore = new Map();

/**@param {Entity} ridingOnEntity */
function flying(ridingOnEntity, entitySpeed) {
    let {
        id, flyRunId
    } = ridingOnEntity;
    stop(flyRunId);
    flyRunId = ridingOnEntity.flyRunId = system.runInterval(() => {
        ridingOnEntity = world.getEntity(id);
        let rideComp = ridingOnEntity?.getComponent("rideable");
        let [rider] = rideComp?.getRiders() ?? [];
        if (!rider) return stop(flyRunId);
        if (rider.getRotation() == ridingOnEntity.getRotation()) return
            let {
                defaultValue: maxHealth,
                currentValue: currentHealth
            } = ridingOnEntity.getComponent("health");
            let riderRot = rider.getRotation();
            let entityRot = ridingOnEntity.getRotation();
            let yaw = entityRot.y + limitAngle(
                riderRot.y - entityRot.y,
                2
            );
            let pitch = entityRot.x + limitAngle((currentHealth > 0.15 * maxHealth ? riderRot.x: 50) - entityRot.x,
                45
            );
            const {
                x,
                y,
                z
            } = ridingOnEntity.getVelocity();
            const speed = Math.hypot(x, y, z);
            let speedNow = speedBefore.get(ridingOnEntity);
            if ((Math.round(speed * 10)) != (Math.round(10 * speedNow))) {
                ridingOnEntity.triggerEvent("explode");
            }
            ridingOnEntity.setRotation({
                x: pitch, y: yaw
            });
            const enttityDir = ridingOnEntity.getViewDirection();
            const vec = vectorMultiply(enttityDir, (currentHealth > 0.15 * maxHealth ? entitySpeed: 1.2));
            ridingOnEntity.clearVelocity();
            ridingOnEntity.applyImpulse(vec);
            let yaw_rotation_y = ridingOnEntity.getRotation().y;
            let rider_yaw_rotation_y = rider.getRotation().y;
            let fullrotation = (1.5*-(rider_yaw_rotation_y - yaw_rotation_y));
            ridingOnEntity.setProperty("fighter:yaw", Math.round(fullrotation));
            if (currentHealth < 0.15 * maxHealth) {
                entitySpeed = 1.2;
            }
            speedBefore.set(ridingOnEntity, entitySpeed);
    })
};

/**@param {Entity} ridingOnEntity */
function hovering(ridingOnEntity) {

    let {
        id, hover
    } = ridingOnEntity;
    stop(hover);
    hover = ridingOnEntity.hover = system.runInterval(() => {
        ridingOnEntity = world.getEntity(id);
        let rideComp = ridingOnEntity?.getComponent("rideable");
        const [rider] = rideComp?.getRiders() ?? [];
        if (!rider) return stop(hover);
        let riderRot = rider.getRotation();
        const {
            x,
            y,
            z
        } = ridingOnEntity.getVelocity();
        const speed = Math.hypot(x, y, z);
        const yVel = ridingOnEntity.getVelocity().y;
        speedBefore.set(ridingOnEntity, speed);
        let {
            value: maxHealth,
            current: currentHealth
        } = ridingOnEntity.getComponent("health");
        if (currentHealth < 0.15 * maxHealth) {
            ridingOnEntity.triggerEvent("explode");
        }
        const hoverLvl = (-riderRot.x * 0.005);
        ridingOnEntity.applyImpulse(vectorMultiply(vecUp, -yVel));
        ridingOnEntity.applyImpulse(vectorMultiply(vecUp, hoverLvl));
    },
        1);
};

/**@param {Entity} ridingOnEntity */
//special thanks to Remember M9#8416 for helping me fix the code!
async function planeFly(ridingOnEntity) {
    let speedLevels = ridingOnEntity.getTags().find(tag => tag.startsWith('speedLevels'))?.replace('speedLevels',
        '');
    speedLevels = speedLevels ? JSON.parse(speedLevels): commonLevels;
    let {
        value: maxHealth,
        current: currentHealth
    } = ridingOnEntity.getComponent("health");
    if (currentHealth < 0.15 * maxHealth) return
    const pastRunId = ridingOnEntity.runId;
    stop(pastRunId);
    const index = await new Promise(resolve => {
        let speedIndex = ridingOnEntity.speedIndex;
        if (typeof speedIndex !== 'number') speedIndex = ridingOnEntity.speedIndex = 0;
        const present = ridingOnEntity.runId = system.runTimeout(() => {
            if (speedIndex > 0) speedIndex = --ridingOnEntity.speedIndex;
            stop(present);
            resolve(speedIndex);
        },
            10);
        if (!testClickInterval(ridingOnEntity, 1)) return;
        if (speedIndex < speedLevels.length - 1) speedIndex = ++ridingOnEntity.speedIndex;
        stop(present);
        resolve(speedIndex);
    });
    const {
        hover, flyRunId
    } = ridingOnEntity;
    switch (index) {
        case 0:
            stop(flyRunId);
            stop(hover);
            break;
        case 1:
            hovering(ridingOnEntity);
            stop(flyRunId);
            break;
        default:
            flying(ridingOnEntity,
                speedLevels[index]);
            stop(hover);
            break;
    };

    ridingOnEntity.triggerEvent("speed_to_" + index);
};

const radToAngle = (180/Math.PI)

function rotationFromVector(vector) {
    const rotation = {};
    rotation.x = -Math.asin(vector.y)*radToAngle;
    const vecXProduct = vector.x <= 0 ? 1: -1;
    rotation.y = vecXProduct * Math.acos(
        (vector.z)/Math.sqrt(
            (vector.x*vector.x)+(vector.z*vector.z)
        )
    )*radToAngle;
    return rotation;
}

let shootIndex = new Map();

world.afterEvents.dataDrivenEntityTrigger.subscribe((event) => {
    const entity = event.entity;
    const eventId = event.eventId;
    if (!entity.typeId.startsWith('sw_')) return;
    if (eventId.startsWith('fire_')) {
        let eventName = eventId.replace('fire_', '');
        let shootTag = entity.getTags().find(t => t.startsWith(`shoot_${eventName}`));
        shootTag = JSON.parse(shootTag.replace(`shoot_${eventName}`, ''));
        const [a,
            b,
            ...locations] = shootTag;
        let lC = locations.length -1;
        if (typeof shootIndex.get(entity.id) !== 'number' || shootIndex.get(entity.id) == lC) {
            shootIndex.set(entity.id, 0);
        } else {
            shootIndex.set(entity.id, shootIndex.get(entity.id) + 1);
        };
        let rideComp = entity?.getComponent("rideable");
        let [rider] = rideComp?.getRiders() ?? [];
        let currentLoc = locations[shootIndex.get(entity.id)];
        let firstx = currentLoc[0];
        let secondy = currentLoc[1];
        let thirdz = currentLoc[2];
        let xheight = currentLoc[3];
        let yheight = currentLoc[4];
        let zheight = currentLoc[5];
        let rotating = currentLoc[6];
        let firstValue = (firstx - xheight);
        let first = Math.sqrt((firstValue * firstValue));
        let second = (secondy - yheight);
        let third = (thirdz - zheight);
        let operation = (firstValue/first);

        let riderRotation = rider.getRotation();
        let entityRotation = entity.getRotation();
        let rotation = -Math.max(-80, Math.min(80, (riderRotation.y - entityRotation.y)));
        let degree = 180 - rotation + 180 - (Math.atan(second/-first) * 180/Math.PI);
        let sqrtValue = Math.sqrt((second * second) + (first * first));
        let xvalue = Math.cos(degree * Math.PI/180) * sqrtValue
        let yvalue = Math.sin(degree * Math.PI/180) * sqrtValue
        const {
            x,
            y,
            z
        } = entity.getVelocity();
        const CurrentSpeed = Math.hypot(x, y, z);
        //some thing
        let EntityLocation = {
            x: (entity.location.x + xheight),
            y: (entity.location.y + yheight),
            z: (entity.location.z + zheight)
        }
        let FinalVec
        if (rotating == 1) {
            FinalVec = vectorAdd(parseVector({
                x: (xvalue * operation), y: yvalue, z: (third + CurrentSpeed + 1)
            }, entity.getViewDirection()), EntityLocation);
        }
        if (rotating == 0) {
            FinalVec = vectorAdd(parseVector({
                x: firstValue, y: second, z: (third + CurrentSpeed + 1)
            }, entity.getViewDirection()), EntityLocation);
        }
        system.run(()=> {
            const projectile = entity.dimension.spawnEntity(`${eventName}`, FinalVec)
            let viewD = entity.getViewDirection();
            let proVec = vectorMultiply(viewD, 9);
            projectile.applyImpulse(proVec);

        })

        let countTo = 0;
        let shooting = system.runInterval(() => {
            countTo++;
            if (countTo == a) {
                system.clearRun(shooting);
                countTo = 0;
            }
            if (typeof shootIndex.get(entity.id) !== 'number' || shootIndex.get(entity.id) == lC) {
                shootIndex.set(entity.id, 0);
            } else {
                shootIndex.set(entity.id, shootIndex.get(entity.id) + 1);
            };
            let rideComp = entity?.getComponent("rideable");
            let [rider] = rideComp?.getRiders() ?? [];
            let currentLoc = locations[shootIndex.get(entity.id)];
            let firstx = currentLoc[0];
            let secondy = currentLoc[1];
            let thirdz = currentLoc[2];
            let xheight = currentLoc[3];
            let yheight = currentLoc[4];
            let zheight = currentLoc[5];
            let rotating = currentLoc[6];
            let firstValue = (firstx - xheight);
            let first = Math.sqrt((firstValue * firstValue));
            let second = (secondy - yheight);
            let third = (thirdz - zheight);
            let operation = (firstValue/first);

            let riderRotation = rider.getRotation();
            let entityRotation = entity.getRotation();
            let rotation = -Math.max(-80, Math.min(80, (riderRotation.y - entityRotation.y)));
            let degree = 180 - rotation + 180 - (Math.atan(second/-first) * 180/Math.PI);
            let sqrtValue = Math.sqrt((second * second) + (first * first));
            let xvalue = Math.cos(degree * Math.PI/180) * sqrtValue;
            let yvalue = Math.sin(degree * Math.PI/180) * sqrtValue;
            let EntityLocation = {
                x: (entity.location.x + xheight),
                y: (entity.location.y + yheight),
                z: (entity.location.z + zheight)
            }
            let FinalVec
            if (rotating == 1) {
                FinalVec = vectorAdd(parseVector({
                    x: (xvalue * operation), y: yvalue, z: (third + CurrentSpeed + 1)
                }, entity.getViewDirection()), EntityLocation);
            }
            if (rotating == 0) {
                FinalVec = vectorAdd(parseVector({
                    x: firstValue, y: second, z: (third + CurrentSpeed + 1)
                }, entity.getViewDirection()), EntityLocation);
            }
            system.run(()=> {
                const projectile2 = entity.dimension.spawnEntity(`${eventName}`, FinalVec)
                let viewD = entity.getViewDirection();
                let Rotation2 = entity.getRotation();
                projectile2.getComponent('minecraft:mark_variant').value = Math.round(Rotation2.y);
                projectile2.getComponent('minecraft:skin_id').value = Math.round(Rotation2.x);
                let proVec = vectorMultiply(viewD, 9);
                projectile2.applyImpulse(proVec);
            })

        },
            b);
    }
});