execute @a[rxm=-90,rx=-25] ~~~ effect @e[family=fighter,r=3, c=1] levitation 1 6 true
execute @a[rxm=-25,rx=-15] ~~~ effect @e[family=fighter,r=3, c=1] levitation 1 3 true
execute @a[rxm=-15,rx=-5] ~~~ effect @e[family=fighter,r=3, c=1] levitation 1 2 true
execute @a[rxm=-5,rx=20] ~~~ effect @e[family=fighter,r=3, c=1] levitation 1 1 true
execute @a[rxm=20,rx=35] ~~~ effect @e[family=fighter,r=3, c=1] slow_falling 1 1 true
execute @a[rxm=35,rx=90] ~~~ effect @e[family=fighter,r=3, c=1] clear